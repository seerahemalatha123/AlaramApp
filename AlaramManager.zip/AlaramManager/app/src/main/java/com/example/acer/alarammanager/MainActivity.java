package com.example.acer.alarammanager;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.CompoundButton;
import android.widget.Toast;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {

    ToggleButton tb;
    AlarmManager manager;
    String  action="com.example.acer.alarammanager";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        tb= findViewById(R.id.mytb);
        manager= (AlarmManager) getSystemService(ALARM_SERVICE);
        tb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                if(isChecked)
                {
                    Toast.makeText(MainActivity.this, "Alaram on", Toast.LENGTH_SHORT).show();
                    Intent i=new Intent(action);
                    PendingIntent p=PendingIntent.getBroadcast(MainActivity.this,1,i,PendingIntent.FLAG_UPDATE_CURRENT);


                    long triggertime= SystemClock.elapsedRealtime()+1*60*1000;
                    long repeattime= 1*60*1000;

                    manager.setInexactRepeating(AlarmManager.ELAPSED_REALTIME_WAKEUP,triggertime,repeattime,p);



                }
                else
                {
                    Toast.makeText(MainActivity.this, "Alarm off", Toast.LENGTH_SHORT).show();
                }

            }
        });

    }


}
